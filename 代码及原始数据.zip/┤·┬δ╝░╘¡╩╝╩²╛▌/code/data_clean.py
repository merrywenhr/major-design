# -*- coding: utf-8 -*-
import pandas as pd

# 显示所有列
pd.set_option('display.max_columns', None)

customers_data = pd.read_csv('../data/Meal_Delivery_Customers.csv')
delivery_data = pd.read_csv('../data/Meal_Delivery_Delivery.csv')
restaurants_data = pd.read_csv('../data/Meal_Delivery_Restaurants.csv')

merged_df = pd.merge(customers_data, delivery_data, on='Order_ID')
# 将Place_Time和Leave_Time的时间只保留时分秒
merged_df['Place_Time'] = pd.to_datetime(merged_df['Place_Time']).dt.time
merged_df['Leave_Time'] = pd.to_datetime(merged_df['Leave_Time']).dt.time

merged_df = pd.merge(merged_df, restaurants_data, on='Restaurant_ID')

# Place_Time: 顾客下单时间  Price: 订单价格（元） Distance: 餐馆与顾客之间的距离（公里）  Last_Hour_Demand: 当前订单前一小时餐馆收到的订单数量
# Leave_Time: 司机离开餐馆送餐时间  Required_Duration: 要求送达时间与下单时间的时间差（分钟）
selected_columns = ['Place_Time', 'Price', 'Distance', 'Last_Hour_Demand', 'Leave_Time', 'Required_Duration', ]
new_data = merged_df[selected_columns]

# 数据去重
new_data = new_data.drop_duplicates()
# 查找包含空值的行
rows_with_nulls = new_data[new_data.isnull().any(axis=1)]

# 重置索引
new_data.reset_index(inplace=True, drop=True)

# 将Place_Time和Leave_Time转换为datetime格式
new_data['Place_Time'] = pd.to_datetime(new_data['Place_Time'], format='%H:%M:%S')
new_data['Leave_Time'] = pd.to_datetime(new_data['Leave_Time'], format='%H:%M:%S')

# 计算备餐时间，单位是分钟
new_data['Pre_Time'] = (new_data['Leave_Time'] - new_data['Place_Time']).dt.total_seconds() / 60


# 定义一个函数来分配时间段
def assign_time_period(time):
    if time.hour >= 7 and time.hour < 9:
        return 'breakfast'
    elif time.hour >= 11 and time.hour < 14:
        return 'lunch'
    elif time.hour >= 17 and time.hour < 20:
        return 'dinner'
    else:
        return 'other'


new_data['Period'] = new_data['Place_Time'].apply(assign_time_period)

# 删除Place_Time Leave_Time得到最终数据
new_data.drop(inplace=True, columns=['Place_Time', 'Leave_Time'])
# print(new_data)
new_data.to_csv('../data/Final_Data.csv')

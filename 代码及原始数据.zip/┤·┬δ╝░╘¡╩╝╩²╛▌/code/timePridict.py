# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import cross_val_score, train_test_split, GridSearchCV

data = pd.read_csv('../data/Final_Data.csv')

# 显示所有列
pd.set_option('display.max_columns', None)

# 读取数据
X = data[['Price', 'Distance', 'Last_Hour_Demand', 'Required_Duration', 'Period']]
X = pd.get_dummies(X, columns=['Period'], drop_first=True)
y = data['Pre_Time']

# 输出学习曲线，寻找最佳n_estimators值
scorel = []
estimators_range = range(1, 100, 20)

# 计算每个 n_estimators 的交叉验证得分
for i in estimators_range:
    rfr = RandomForestRegressor(n_estimators=i, n_jobs=-1, random_state=90)
    score = cross_val_score(rfr, X, y, cv=10).mean()
    scorel.append(score)

# 找到最佳分数和对应的 n_estimators
best_score = max(scorel)
best_n_estimators = (scorel.index(best_score) * 10) + 1

print(best_n_estimators, best_score)

# 绘制结果
plt.figure(figsize=[20, 5])
plt.plot(estimators_range, scorel, marker='o')
plt.xlabel('n_estimators')
plt.ylabel('Accuracy')
plt.title('Accuracy for Different n_estimators')
plt.grid(True)
plt.show()

# 网格调优
# # 定义参数范围
# param_grid = {
#     'min_samples_split': range(50, 60, 1),
#     'min_samples_leaf': range(1, 21, 2)
# }
#
# # 使用 GridSearchCV 搜索最佳参数
# grid_search = GridSearchCV(RandomForestRegressor(n_estimators=42, random_state=42), param_grid, cv=3)
# grid_search.fit(X_train, y_train)
#
# # 最佳参数
# best_min_samples_split = grid_search.best_params_['min_samples_split']
# best_min_samples_leaf = grid_search.best_params_['min_samples_leaf']
# print(best_min_samples_split, best_min_samples_leaf)

# # 定义参数范围
# param_grid = {'max_features': [3, 5, 7, 9, 11]}
#
# # 使用 GridSearchCV 搜索最佳 max_features
# grid_search = GridSearchCV(RandomForestRegressor(n_estimators=42,
#                                                  min_samples_split=54,
#                                                  min_samples_leaf=19,
#                                                  random_state=42), param_grid, cv=3)
# grid_search.fit(X_train, y_train)
#
# # 最佳 max_features
# best_max_features = grid_search.best_params_['max_features']
# print(best_max_features)

# 使用最佳参数训练模型
best_model = RandomForestRegressor(n_estimators=42,
                                   min_samples_split=54,
                                   min_samples_leaf=200,
                                   max_features=5,
                                   random_state=42)

# score_pre = cross_val_score(best_model, X, y, cv=10).mean()  # 交叉验证的分类默认scoring='accuracy'
# print(score_pre)
best_model.fit(X, y)

x = [[20, 3.6, 17, 40, 0, 0, 0]]
# x1: “Price”(订单价格)，数值型变量。
# x2: “Distance”（餐馆与顾客之间的距离），数值型变量。
# x3: “Last_Hour_Demand”（当前订单前一小时餐馆收到的订单数量），数值型变量，取值为非负整数。
# x4: “Required_Duration”（要求送达时间与下单时间的时间差），数值型变量。
# x5: “Period_dinner”（晚餐），数值型变量，取值为0或1。
# x6: “Period_lunch”（午餐），数值型变量，取值为0或1。
# x7: “Period_other”（其他），数值型变量，取值为0或1。
# 预测
# predictions = best_model.predict(X_test)
predictions_x = best_model.predict(x)
print(predictions_x)
# print(X_test)
# print(predictions)

# 计算均方误差
# mse = mean_squared_error(y_test, predictions)
# print(mse)

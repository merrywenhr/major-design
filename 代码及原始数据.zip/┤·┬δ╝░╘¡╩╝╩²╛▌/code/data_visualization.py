# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

data = pd.read_csv('../data/Final_Data.csv')
# print(data)

# 备餐时长分布
# plt.figure(figsize=(10, 6))
# sns.histplot(data['Pre_Time'], bins=30, kde=True)
# plt.title('备餐时长分布')
# plt.xlabel('备餐时长')
# plt.ylabel('频数')
# plt.show()

# 备餐时长相关性
# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Price', y='Pre_Time', data=data)
# plt.title('价格与备餐时长的关系')
# plt.xlabel('价格')
# plt.ylabel('备餐时长')
# plt.show()

# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Distance', y='Pre_Time', data=data)
# plt.title('距离与备餐时长的关系')
# plt.xlabel('距离')
# plt.ylabel('备餐时长')
# plt.show()

# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Last_Hour_Demand', y='Pre_Time', data=data)
# plt.title('下单前一小时订单数与备餐时长的关系')
# plt.xlabel('下单前一小时订单数')
# plt.ylabel('备餐时长')
# plt.show()

# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Required_Duration', y='Pre_Time', data=data)
# plt.title('要求送达时间与备餐时长的关系')
# plt.xlabel('要求送达时间')
# plt.ylabel('备餐时长')
# plt.show()
